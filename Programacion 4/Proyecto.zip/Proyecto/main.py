from interfaz import menu
from persistencia import cargar

if __name__ == "__main__":
    cargar()
    menu()
